/**
  ******************************************************************************
  * @file    pt32z192xx_ana.h
  * @author  Ӧ�ÿ����Ŷ�
  * @version 
  * @date    
  * @brief   
  *          
  ******************************************************************************
  * @attention
  *
  * 
  *
  * 
  * 
  * 
  *
  *      
  *
  * 
  *
  * 
  * 
  *
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __PT32Z192XX_ANA_H
#define __PT32Z192XX_ANA_H

#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "pt32z192xx.h"

/** @addtogroup PT32Z192xx_StdPeriph_Driver
  * @{
  */

/** @addtogroup ANA
  * @{
  */

/* Exported types ------------------------------------------------------------*/



/* Exported constants --------------------------------------------------------*/

/** @defgroup ANA_Exported_Constants
  * @{
  */



/** @addtogroup ANA_Exported_Functions
  * @{
  */
  

/**
  * @}
  */
#ifdef __cplusplus
}
#endif

#endif /* __PT32Z192XX_ANA_H */

/**
  * @}
  */

/**
  * @}
  */ 

/**
  * @}
  */ 
	
/************************  *****END OF FILE****/

